import { gameData, levelData, gameScreen } from "../variables.js";
import { EnemyCarousel } from "./lines-builder.js";

window.addEventListener("resize", createGameScreen);

let enemyLoopId = null;
let currentCarousel = null;

function createGameScreen() {
  // offsetWidth renvoie un nombre (0 si l'élément est caché)
  let width = gameScreen.offsetWidth;

  // fallback si width est invalide
  if (!width || isNaN(width)) {
    console.warn("Largeur invalide, on force une valeur par défaut");
    width = 800; // valeur par défaut
  }

  screenConfig.screenWidth = width;

  screenConfig.enemiesPerLine = levelData.enemiesPerLine;
  const availableWidth = screenConfig.screenWidth - 200;
  screenConfig.enemySpacingX =
    availableWidth / (screenConfig.enemiesPerLine - 1);
  if (screenConfig.enemySpacingX < 30) screenConfig.enemySpacingX = 30;

  if (window.innerHeight > window.innerWidth) {
    screenConfig.speed = 0.03;
    gameData.speed = 3;
  } else {
    screenConfig.speed = 2;
    gameData.speed = 5;
  }

  console.log("screenConfig:", screenConfig);
}

const screenConfig = {
  screenWidth: 800,
  enemiesPerLine: 12,
  enemySpacingX: 70, // Sera recalculé dans createGameScreen
  lineSpacingY: 60,
  moveSpeedX: 2,
};

function newCarousel() {
  createGameScreen();
  console.log(
    `Largeur écran: ${screenConfig.screenWidth}, Espacement: ${screenConfig.enemySpacingX}`
  );
  currentCarousel = new EnemyCarousel(screenConfig, levelData);
  return currentCarousel;
}

function enemyLoop(carousel) {
  if (carousel) carousel.update();
  enemyLoopId = requestAnimationFrame(() => enemyLoop(carousel));
}

function pauseEnemyLoop() {
  if (!enemyLoopId) return;
  cancelAnimationFrame(enemyLoopId);
  enemyLoopId = null;
}

function resumeEnemyLoop() {
  if (typeof enemyLoopId === "number") {
    console.log("❌ Boucle déjà active, enemyLoopId =", enemyLoopId);
    return;
  }
  if (!currentCarousel) {
    console.error("❌ PROBLÈME : currentCarousel est null/undefined !");
    return;
  }
  enemyLoop(currentCarousel);
}

function getEnemyLoopId() {
  return enemyLoopId;
}

export { getEnemyLoopId };

export { createGameScreen };
export { enemyLoop, newCarousel, pauseEnemyLoop, resumeEnemyLoop };
