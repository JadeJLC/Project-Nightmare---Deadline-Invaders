import { newCarousel } from "../enemies/enemies.js";
import { EnemyCarousel, EnemyLine } from "../enemies/lines-builder.js"; // Assure l'import d'EnemyLine
import { enableEnemyShooting } from "../mechanics/enemy-shooting.js";
import { enableShooting } from "../mechanics/player-shooting.js";
import { allLevelData, gameData } from "../variables.js";
import { enableMovement } from "../mechanics/player-movement.js";
import { createGameScreen } from "../enemies/enemies.js";
import {
  updateProgressBar,
  updateProgressScore,
} from "../scores/progress-bar.js";

class EndlessMode {
  constructor(carousel, levelConfig) {
    this.carousel = carousel;
    this.levelConfig = levelConfig;
    this.spawnY = 60; // position en haut
  }

  update() {
    // 1. Mettre à jour les lignes existantes
    this.carousel.update();

    // 1bis. En mode Endless : si une ligne n'a plus de coworkers vivants, supprimer aussi les relous
    this.carousel.lines.forEach((line) => {
      const coworkersAlive = line.enemies.some(
        (e) => e.type === "coworker" && e.isAlive
      );
      if (!coworkersAlive) {
        line.enemies.forEach((e) => {
          if (e.type === "relou") {
            e.isAlive = false;
            if (e.el) e.el.remove(); // supprime du DOM
          }
        });
        // Nettoyer le tableau
        line.enemies = line.enemies.filter((e) => e.isAlive);
      }
    });

    // 2. Retirer les lignes qui ne contiennent plus que des relous
    this.carousel.lines = this.carousel.lines.filter(
      (line) => !line.onlyRelous()
    );

    // 3. Tant qu'il manque des lignes, descendre et recréer
    while (this.carousel.lines.length < this.levelConfig.lineCount) {
      this.descendLines();
      this.addNewLine();
    }

    // 4. Debug (optionnel)
    this.carousel.lines.forEach((line, i) => {
      line.onlyRelous();
    });
  }

  descendLines() {
    this.carousel.lines.forEach((line) => {
      line.enemies.forEach((enemy) => {
        enemy.baseY += this.carousel.cfg.lineSpacingY; // important: baseY !
      });
    });
  }

  addNewLine() {
    const index = this.carousel.lines.length; // pour varier direction
    const direction = index % 2 === 0 ? "right" : "left";
    const newLine = new EnemyLine(
      this.spawnY,
      direction,
      this.carousel.cfg,
      this.levelConfig.relouPerLine,
      0 // lineIndex utilisé pour le léger offset horizontal si tu le gardes
    );
    this.carousel.lines.unshift(newLine);
  }

  setLevelConfig(nextConfig) {
    this.levelConfig = nextConfig;
  }
}

let levelConfig = allLevelData[1];
let rafId = null;

function gameLoop(endless) {
  // Adapter la difficulté selon le score
  if (
    gameData.goodScore - gameData.badScore > 200 &&
    gameData.goodScore - gameData.badScore <= 400
  ) {
    endless.setLevelConfig(allLevelData[2]);
  } else if (gameData.goodScore - gameData.badScore > 400) {
    endless.setLevelConfig(allLevelData[3]);
  }

  endless.update();
  rafId = requestAnimationFrame(() => gameLoop(endless));
}

function startEndless() {
  console.log("Atteint initEndless");
  const carousel = newCarousel();
  console.log("Passe carousel");
  const endless = new EndlessMode(carousel, levelConfig);
  console.log("Passe endless");

  // Reset état du jeu
  gameData.badScore = 0;
  gameData.goodScore = 0;
  gameData.countPoint = true;

  // Activer les contrôles et tirs (tes fonctions existantes)
  //updateProgressBar();
  enableShooting();
  enableEnemyShooting();
  enableMovement();
  updateProgressScore();

  // Lancer la boucle
  gameLoop(endless);
}

// Optionnel: pause/reprise
function pauseEndless() {
  cancelAnimationFrame(rafId);
  rafId = null;
}

export { startEndless, pauseEndless };
